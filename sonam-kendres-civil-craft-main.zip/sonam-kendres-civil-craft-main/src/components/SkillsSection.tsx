
import React, { useEffect } from 'react';
import { cn } from '@/lib/utils';

interface Skill {
  name: string;
  icon: string;
  description: string;
  level: number; // 1-5
  category: 'technical' | 'soft';
}

const skills: Skill[] = [
  {
    name: "Structural Design",
    icon: "🏗️",
    description: "Proficient in designing load-bearing structures with efficiency and safety.",
    level: 5,
    category: 'technical'
  },
  {
    name: "Project Management",
    icon: "📋",
    description: "Experienced in planning, executing, and overseeing civil engineering projects.",
    level: 4,
    category: 'technical'
  },
  {
    name: "Construction Technology",
    icon: "🏢",
    description: "Knowledge of modern construction techniques and materials.",
    level: 4,
    category: 'technical'
  },
  {
    name: "Soil Mechanics",
    icon: "🧱",
    description: "Understanding of soil behavior for foundation design and earthworks.",
    level: 4,
    category: 'technical'
  },
  {
    name: "Blueprint Reading",
    icon: "📝",
    description: "Expert in interpreting and creating technical drawings and blueprints.",
    level: 5,
    category: 'technical'
  },
  {
    name: "Sustainable Design",
    icon: "🌱",
    description: "Focus on environmentally conscious engineering solutions.",
    level: 4,
    category: 'technical'
  },
  {
    name: "Leadership",
    icon: "👥",
    description: "Ability to guide teams and make decisive choices in project execution.",
    level: 4,
    category: 'soft'
  },
  {
    name: "Problem Solving",
    icon: "🧩",
    description: "Analytical approach to identifying and resolving engineering challenges.",
    level: 5,
    category: 'soft'
  },
  {
    name: "Communication",
    icon: "💬",
    description: "Clear articulation of technical concepts to diverse audiences.",
    level: 4,
    category: 'soft'
  },
  {
    name: "Adaptability",
    icon: "🔄",
    description: "Flexible approach to changing project requirements and conditions.",
    level: 4,
    category: 'soft'
  },
];

const SkillsSection: React.FC = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1 });

    const hiddenElements = document.querySelectorAll('.reveal');
    hiddenElements.forEach((el) => observer.observe(el));

    return () => {
      hiddenElements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  const technicalSkills = skills.filter(skill => skill.category === 'technical');
  const softSkills = skills.filter(skill => skill.category === 'soft');

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="section-container">
        <h2 className="section-title reveal">My Skills</h2>
        <div className="section-subtitle reveal">Professional capabilities that define my expertise</div>
        
        <div className="mt-12">
          <h3 className="text-2xl font-semibold mb-6 text-center reveal font-heading">Technical Skills</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {technicalSkills.map((skill, index) => (
              <div 
                key={skill.name}
                className="skill-card reveal"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="text-3xl mb-3">{skill.icon}</div>
                <h4 className="text-xl font-semibold mb-2 font-heading">{skill.name}</h4>
                <p className="text-gray-600 mb-4">{skill.description}</p>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-primary h-2 rounded-full" 
                    style={{ width: `${(skill.level / 5) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
          
          <h3 className="text-2xl font-semibold mb-6 text-center reveal font-heading">Soft Skills</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {softSkills.map((skill, index) => (
              <div 
                key={skill.name}
                className="skill-card reveal"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="text-3xl mb-3">{skill.icon}</div>
                <h4 className="text-xl font-semibold mb-2 font-heading">{skill.name}</h4>
                <p className="text-gray-600 mb-4">{skill.description}</p>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-primary h-2 rounded-full" 
                    style={{ width: `${(skill.level / 5) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
