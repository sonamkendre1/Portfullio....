
import React, { useEffect } from 'react';
import { cn } from '@/lib/utils';

const AboutSection: React.FC = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1 });

    const hiddenElements = document.querySelectorAll('.reveal');
    hiddenElements.forEach((el) => observer.observe(el));

    return () => {
      hiddenElements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  return (
    <section id="about" className="py-20 bg-white">
      <div className="section-container">
        <h2 className="section-title reveal">About Me</h2>
        <div className="section-subtitle reveal">Passion for Sustainable Development and Innovative Construction</div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-12">
          {/* Photo */}
          <div className="flex justify-center md:justify-end reveal">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 rounded-lg transform translate-x-4 translate-y-4"></div>
              <img 
                src="/lovable-uploads/b3bd3436-283d-4418-8553-4934f3477139.png"
                alt="Sonam Kendre" 
                className="relative z-10 rounded-lg shadow-lg w-full max-w-md object-cover object-center h-[400px]"
              />
            </div>
          </div>
          
          {/* Content */}
          <div className="reveal">
            <h3 className="text-2xl font-bold mb-4 text-primary font-heading">Hi, I'm Sonam</h3>
            <p className="text-gray-700 mb-4">
              I am a passionate Civil Engineering graduate with a keen interest in sustainable 
              development and innovative construction methodologies. With a strong foundation in 
              structural design principles and project management, I aim to contribute to the 
              creation of resilient and environmentally conscious infrastructure.
            </p>
            <p className="text-gray-700 mb-6">
              My academic journey has equipped me with comprehensive knowledge in various aspects 
              of civil engineering, from structural analysis and design to construction management 
              and environmental considerations. I believe in the power of thoughtful design and 
              engineering to create spaces that not only meet functional requirements but also 
              enhance the quality of life for communities.
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-2">Education</h4>
                <ul className="text-gray-700 space-y-1">
                  <li>B.Tech in Civil Engineering</li>
                  <li>Advanced Certification in Structural Design</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Interests</h4>
                <ul className="text-gray-700 space-y-1">
                  <li>Sustainable Infrastructure</li>
                  <li>Structural Innovation</li>
                  <li>Project Management</li>
                  <li>Green Building Design</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
