
import React, { useEffect } from 'react';
import { cn } from '@/lib/utils';

interface Internship {
  company: string;
  role: string;
  duration: string;
  description: string;
  skills: string[];
  image: string;
}

const internships: Internship[] = [
  {
    company: "ABC Construction",
    role: "Structural Engineering Intern",
    duration: "May 2023 - August 2023",
    description: "Assisted in structural analysis and design of residential buildings. Participated in site inspections and quality control procedures.",
    skills: ["STAAD.Pro", "AutoCAD", "Structural Analysis", "Site Inspection"],
    image: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?q=80&w=1664&auto=format&fit=crop"
  },
  {
    company: "XYZ Infrastructure",
    role: "Project Management Intern",
    duration: "January 2023 - April 2023",
    description: "Supported project managers in scheduling, cost estimation, and resource allocation for highway development projects.",
    skills: ["MS Project", "Cost Estimation", "Resource Planning", "Documentation"],
    image: "https://images.unsplash.com/photo-1590486803833-1c5dc8ddd4c8?q=80&w=1887&auto=format&fit=crop"
  },
  {
    company: "Construction Site, Latur, Maharashtra",
    role: "On-site Civil Engineering Intern",
    duration: "July 2023 - September 2023",
    description: "Gained hands-on experience at a construction site in Latur, Maharashtra. Worked with local contractors and engineers on structural formwork and site supervision.",
    skills: ["Site Supervision", "Formwork", "Construction Methods", "Team Coordination"],
    image: "/lovable-uploads/58d711d5-4a71-4c19-b636-d1a61cd037b4.png"
  },
  {
    company: "Green Building Solutions",
    role: "Sustainability Intern",
    duration: "June 2022 - August 2022",
    description: "Researched sustainable building materials and assisted in LEED certification documentation for commercial buildings.",
    skills: ["Sustainable Design", "LEED", "Research", "Green Materials"],
    image: "https://images.unsplash.com/photo-1480074568708-e7b720bb3f09?q=80&w=1474&auto=format&fit=crop"
  },
  {
    company: "Urban Planning Associates",
    role: "Civil Design Intern",
    duration: "January 2022 - April 2022",
    description: "Contributed to urban development projects focusing on drainage systems and transportation infrastructure.",
    skills: ["Civil 3D", "Urban Planning", "Drainage Design", "Transportation"],
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1470&auto=format&fit=crop"
  },
];

const InternshipsSection: React.FC = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1 });

    const hiddenElements = document.querySelectorAll('.reveal');
    hiddenElements.forEach((el) => observer.observe(el));

    return () => {
      hiddenElements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  return (
    <section id="internships" className="py-20 bg-gray-50">
      <div className="section-container">
        <h2 className="section-title reveal">Internship Experience</h2>
        <div className="section-subtitle reveal">Practical experience that has shaped my professional journey</div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
          {internships.map((internship, index) => (
            <div 
              key={internship.company}
              className="internship-card reveal overflow-hidden"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative h-60 mb-4 overflow-hidden rounded-t-lg">
                <img 
                  src={internship.image} 
                  alt={internship.company} 
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
              <h3 className="text-xl font-bold text-primary mb-1 font-heading">{internship.company}</h3>
              <h4 className="text-lg font-semibold mb-1">{internship.role}</h4>
              <p className="text-gray-500 mb-3">{internship.duration}</p>
              <p className="text-gray-700 mb-4">{internship.description}</p>
              <div className="flex flex-wrap gap-2">
                {internship.skills.map(skill => (
                  <span 
                    key={skill} 
                    className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default InternshipsSection;
