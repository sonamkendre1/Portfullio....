
import React from 'react';

const HeroSection: React.FC = () => {
  const handleScrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=1740&auto=format&fit=crop')`,
        }}
      >
        <div className="absolute inset-0 bg-black opacity-60"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 text-white">
        <div className="max-w-3xl">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold font-heading mb-4 animate-fade-in">
            Sonam Kendre
          </h1>
          <h2 className="text-xl sm:text-2xl md:text-3xl font-medium mb-8 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            B.Tech in Civil Engineering
          </h2>
          <p className="text-lg mb-10 max-w-2xl animate-fade-in" style={{ animationDelay: '0.4s' }}>
            Passionate about sustainable development and innovative construction solutions. 
            Specialized in structural design with a focus on eco-friendly practices.
          </p>
          <div className="flex flex-wrap gap-4 animate-fade-in" style={{ animationDelay: '0.6s' }}>
            <button 
              className="btn-primary"
              onClick={() => handleScrollToSection('about')}
            >
              Learn About Me
            </button>
            <button 
              className="btn-outline"
              onClick={() => handleScrollToSection('contact')}
            >
              Get In Touch
            </button>
          </div>
        </div>
      </div>
      
      {/* Scroll Down Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <button 
          onClick={() => handleScrollToSection('about')}
          className="text-white flex flex-col items-center opacity-80 hover:opacity-100 transition-opacity"
        >
          <span className="mb-2 text-sm">Scroll Down</span>
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-6 w-6" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </button>
      </div>
    </section>
  );
};

export default HeroSection;
