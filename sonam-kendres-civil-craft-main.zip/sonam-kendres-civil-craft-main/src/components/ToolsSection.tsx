
import React, { useEffect } from 'react';

interface Tool {
  name: string;
  icon: string;
  description: string;
}

const tools: Tool[] = [
  {
    name: "AutoCAD",
    icon: "📐",
    description: "Expert in 2D drafting and design for civil engineering projects."
  },
  {
    name: "STAAD.Pro",
    icon: "🏗️",
    description: "Proficient in structural analysis and design using STAAD.Pro."
  },
  {
    name: "Revit",
    icon: "🏢",
    description: "Skilled in BIM modeling and documentation for construction projects."
  },
  {
    name: "SketchUp",
    icon: "✏️",
    description: "Experienced in 3D modeling and visualization for architectural concepts."
  },
  {
    name: "MS Project",
    icon: "📊",
    description: "Adept at project scheduling, tracking, and resource management."
  },
  {
    name: "Civil 3D",
    icon: "🛣️",
    description: "Proficient in civil engineering design and documentation."
  },
  {
    name: "ETABS",
    icon: "🏙️",
    description: "Skilled in building analysis and design for structural engineering."
  },
  {
    name: "SAP2000",
    icon: "🌉",
    description: "Experienced in structural analysis and design for various infrastructure."
  }
];

const ToolsSection: React.FC = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1 });

    const hiddenElements = document.querySelectorAll('.reveal');
    hiddenElements.forEach((el) => observer.observe(el));

    return () => {
      hiddenElements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  return (
    <section id="tools" className="py-20 bg-gray-50">
      <div className="section-container">
        <h2 className="section-title reveal">Software & Tools</h2>
        <div className="section-subtitle reveal">Professional tools I use to bring designs and structures to life</div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-12">
          {tools.map((tool, index) => (
            <div 
              key={tool.name}
              className="tool-card reveal"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="text-4xl mb-3">{tool.icon}</div>
              <h3 className="text-xl font-semibold mb-2 font-heading">{tool.name}</h3>
              <p className="text-gray-600">{tool.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ToolsSection;
